#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

enum { THREADS = 4, LOOPS = 250000 };
static long counter = 0;

static void *increment(void *unused) {
    (void)unused;
    for (long i = 0; i < LOOPS; i++) counter++;
    return NULL;
}

int main(void) {
    pthread_t workers[THREADS];
    for (int i = 0; i < THREADS; i++)
        if (pthread_create(&workers[i], NULL, increment, NULL) != 0) return EXIT_FAILURE;
    for (int i = 0; i < THREADS; i++) pthread_join(workers[i], NULL);
    printf("expected=%d actual=%ld\n", THREADS * LOOPS, counter);
    return EXIT_SUCCESS;
}
