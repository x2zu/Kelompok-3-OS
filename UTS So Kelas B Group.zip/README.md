# Paket UTS Praktikum Sistem Operasi

Paket ini berisi naskah UTS dan starter code yang dirujuk langsung oleh soal. Kerjakan ujian di VM/build OS hasil kerja kelompok Anda sendiri.

## Isi paket

- `Soal/UTS_Praktikum_Sistem_Operasi.docx` — naskah ujian lima soal.
- `Starter/Soal-4-Process/mini_executor_skeleton.c` — kerangka program untuk soal process.
- `Starter/Soal-5-Thread/race_counter.c` — program awal race condition tanpa mutex.

## Persiapan sebelum ujian

1. Unduh dan ekstrak seluruh ZIP ini.
2. Baca naskah soal dan pastikan VM/build OS kelompok Anda dapat dijalankan. Gunakan salinan kerja atau snapshot pribadi.
3. Pastikan compiler `gcc` tersedia di OS kelompok. Jangan memasang paket atau mengubah OS utama saat ujian. Jika tidak tersedia, catat kondisi tersebut dan ikuti arahan dosen.
4. Buat direktori kerja pribadi di VM OS kelompok, lalu salin starter yang diperlukan dari folder hasil ekstrak paket ini. Ganti `<NIM>` dengan NIM Anda sendiri.

Contoh menyiapkan salinan kerja source (jalankan dari folder hasil ekstrak paket):

```bash
mkdir -p "$HOME/uts-kelompok/src" "$HOME/uts-kelompok/bin"
cp Starter/Soal-4-Process/mini_executor_skeleton.c "$HOME/uts-kelompok/src/"
cp Starter/Soal-5-Thread/race_counter.c "$HOME/uts-kelompok/src/"
cd "$HOME/uts-kelompok"
```

Paket hasil ekstrak biasanya berada di komputer yang menjalankan Word/ZIP, sedangkan OS kelompok berjalan di VM. Pindahkan folder `Starter` ke VM melalui fitur shared folder VirtualBox, drag-and-drop bila sudah tersedia, atau salin-tempel melalui media yang biasa dipakai kelompok. Setelah folder `Starter` tampak dari Terminal VM, jalankan perintah salin di atas dari direktori paket. Jika folder paket tidak dapat diakses langsung dari VM, salin kedua file `.c` ke VM dahulu, lalu jalankan:

```bash
mkdir -p "$HOME/uts-kelompok/src" "$HOME/uts-kelompok/bin"
cp mini_executor_skeleton.c "$HOME/uts-kelompok/src/"
cp race_counter.c "$HOME/uts-kelompok/src/"
```

Jangan mengedit starter asli di folder paket; kerjakan salinan di direktori pribadi.

## Compile sesuai soal

Dari direktori kerja pribadi di VM OS kelompok:

```bash
gcc -Wall -Wextra -o bin/mini_executor src/mini_executor_skeleton.c
gcc -Wall -Wextra -pthread -o bin/race_counter src/race_counter.c
```

Untuk soal 4, lengkapi TODO pada salinan `mini_executor_skeleton.c` sesuai instruksi naskah. Untuk soal 5, ubah salinan `race_counter.c` dengan menambahkan mutex sesuai instruksi naskah, lalu compile ulang.

## Bukti pengerjaan

Lampirkan perintah dan keluaran aktual dari VM/build OS kelompok sendiri, serta penjelasan sesuai permintaan pada setiap soal. Jangan menampilkan password, token, atau data pribadi host. Ikuti tenggat dan media pengumpulan yang ditetapkan dosen.
