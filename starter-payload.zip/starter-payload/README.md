# Berkas Latihan Project Akhir 0

Berkas latihan ini mengikuti struktur `TRPL-CustomOS-Project-Starter` versi 1.1.1. Kelompok memasang XFCE dan LightDM pada VM, mengatur tampilan, lalu memakai konfigurasi `configs/project.env` dari starter yang sama. Program C di `branding/wallpaper/generate-brand.c` membaca identitas produk itu, menampilkan banner ASCII, dan membuat source wallpaper SVG. PNG yang diekspor kelak menjadi aset wallpaper untuk starter.

Ikuti `docs/PRAKTIK_XFCE.md` dan modul utama. Instalasi serta penghapusan paket hanya dilakukan pada VM yang memiliki snapshot VirtualBox. Jangan menjalankan perintah tersebut pada macOS. GNOME dihapus setelah XFCE diuji dan simulasi APT disetujui dosen; tidak ada langkah memasang GNOME kembali. Perubahan Plymouth memerlukan snapshot tambahan dan pendampingan dosen.

Salin template project.env dengan nama konfigurasi aktif. Formatnya data `KEY="VALUE"`; jangan menjalankan atau memuatnya dengan perintah `source`.

```bash
cp -r starter-payload "$HOME/trpl-customos-project"
cd "$HOME/trpl-customos-project"
cp configs/project.env.example configs/project.env
chmod +x bin/trpl-healthcheck.sh tests/check-prototype.sh
mkdir -p evidence
```

Isi nilai proyek pada `configs/project.env`. Untuk latihan branding, nilai minimum yang dipakai adalah `OS_NAME`, `OS_ID`, `OS_VERSION`, `BUILD_CHANNEL`, `BUILD_ID`, dan `BRANDING_WALLPAPER_PATH`. File lengkap pada starter resmi juga berisi pengaturan target dan kebijakan proyek. Parser starter membaca file sebagai data dan tidak mengeksekusi shell.

Jalankan pemeriksaan latihan tanpa `sudo`:

```bash
bash tests/check-prototype.sh
bash bin/trpl-healthcheck.sh | tee evidence/healthcheck.txt
```

## Membuat banner dan wallpaper dari satu program C

Program `branding/wallpaper/generate-brand.c` membaca `configs/project.env`. Saat dijalankan, program mencetak banner ASCII dan menghasilkan source SVG di `branding/wallpaper/` dengan identitas yang sama. Source file ini juga berada pada jalur yang sama dalam starter proyek resmi. Jika perintah `cc` belum tersedia, minta dosen menyetujui pemasangan compiler: `sudo apt update`, lalu `sudo apt install build-essential`.

```bash
cc -Wall -Wextra -std=c11 branding/wallpaper/generate-brand.c -o /tmp/generate-brand
/tmp/generate-brand configs/project.env
```

Argumen pertama adalah lokasi `project.env`; argumen kedua, bila diberikan, menentukan nama SVG keluaran. File konfigurasi tidak dijalankan sebagai shell script. Executable di `/tmp` hanya untuk uji lokal dan tidak perlu dikumpulkan.

Buka SVG yang dihasilkan di peramban atau Inkscape untuk memeriksanya dan mengubah source. Ekspor hasilnya menjadi PNG, lalu terapkan pada XFCE lewat `Settings` > `Desktop` > `Background`. Catat lokasi pemasangan PNG pada `BRANDING_WALLPAPER_PATH` di `configs/project.env`. Dalam starter resmi, PNG yang diuji menjadi aset yang kelak dipasang ke sistem; SVG merupakan source editable.

Program hanya membuat berkas SVG di folder proyek dan mencetak identitas produk ke terminal. Program tidak mengubah berkas sistem atau konfigurasi shell. Jangan kumpulkan executable sementara dari `/tmp`; kumpulkan source C, konfigurasi latihan, SVG, PNG ekspor, dan bukti hasil.

Jika desktop akhir bermasalah, jangan memasang GNOME kembali atau menjalankan `apt autoremove`. Pulihkan snapshot awal bersama dosen. Berkas dalam `systemd/` hanya untuk dibaca; jangan memasang atau mengaktifkannya.
