#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*
 * Read the starter's data-only configs/project.env (never source/eval it),
 * print a terminal identity banner, and generate an editable SVG wallpaper.
 */
static int copy_config_value(const char *file, const char *key,
                             char *out, size_t capacity) {
    FILE *fp = fopen(file, "r");
    if (!fp) return 0;

    char line[4096];
    size_t key_len = strlen(key);
    int found = 0;
    while (fgets(line, sizeof line, fp)) {
        char *p = line;
        while (isspace((unsigned char)*p)) ++p;
        if (*p == '#' || *p == '\0' || *p == '\n') continue;
        if (strncmp(p, key, key_len) != 0 || p[key_len] != '=') continue;
        p += key_len + 1;
        if (*p != '"') break;
        ++p;
        char *end = strchr(p, '"');
        if (!end || (end[1] != '\n' && end[1] != '\0' && end[1] != '\r')) break;
        size_t n = (size_t)(end - p);
        if (n >= capacity) break;
        memcpy(out, p, n);
        out[n] = '\0';
        found = 1;
        break;
    }
    fclose(fp);
    return found;
}

static void xml_text(FILE *fp, const char *text) {
    for (; *text; ++text) {
        switch (*text) {
            case '&': fputs("&amp;", fp); break;
            case '<': fputs("&lt;", fp); break;
            case '>': fputs("&gt;", fp); break;
            case '"': fputs("&quot;", fp); break;
            case '\'': fputs("&apos;", fp); break;
            default: fputc(*text, fp);
        }
    }
}

int main(int argc, char **argv) {
    const char *config = argc > 1 ? argv[1] : "configs/project.env";
    char name[256], id[128], version[128], channel[128], build[256], install_path[512];
    if (!copy_config_value(config, "OS_NAME", name, sizeof name) ||
        !copy_config_value(config, "OS_ID", id, sizeof id) ||
        !copy_config_value(config, "OS_VERSION", version, sizeof version) ||
        !copy_config_value(config, "BUILD_CHANNEL", channel, sizeof channel) ||
        !copy_config_value(config, "BUILD_ID", build, sizeof build) ||
        !copy_config_value(config, "BRANDING_WALLPAPER_PATH", install_path, sizeof install_path)) {
        fprintf(stderr, "GAGAL: isi OS_NAME, OS_ID, OS_VERSION, BUILD_CHANNEL, BUILD_ID, dan BRANDING_WALLPAPER_PATH di %s.\n", config);
        return 2;
    }

    char output[512];
    if (argc > 2) {
        snprintf(output, sizeof output, "%s", argv[2]);
    } else {
        snprintf(output, sizeof output, "branding/wallpaper/%s-%s.svg", id, version);
    }

    printf("\n  +----------------------------------------+\n");
    printf("  |  TRPL CUSTOM OS - DEVELOPMENT BUILD   |\n");
    printf("  |  %-37.37s |\n", name);
    printf("  |  ID: %-34.34s |\n", id);
    printf("  |  Version: %-29.29s |\n", version);
    printf("  +----------------------------------------+\n");
    printf("  Channel: %s\n  Build:   %s\n\n", channel, build);

    FILE *svg = fopen(output, "w");
    if (!svg) {
        perror("GAGAL: tidak dapat membuat SVG");
        return 1;
    }
    fputs("<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"1920\" height=\"1080\" viewBox=\"0 0 1920 1080\">\n", svg);
    fputs("  <defs><linearGradient id=\"bg\" x2=\"1\" y2=\"1\"><stop stop-color=\"#10253f\"/><stop offset=\"1\" stop-color=\"#174f68\"/></linearGradient></defs>\n", svg);
    fputs("  <rect width=\"1920\" height=\"1080\" fill=\"url(#bg)\"/>\n", svg);
    fputs("  <path d=\"M0 850 C420 650 690 1120 1120 840 S1650 720 1920 820\" fill=\"none\" stroke=\"#36c2d4\" stroke-opacity=\".35\" stroke-width=\"5\"/>\n", svg);
    fputs("  <circle cx=\"1550\" cy=\"230\" r=\"190\" fill=\"#36c2d4\" fill-opacity=\".13\"/>\n", svg);
    fputs("  <rect x=\"145\" y=\"185\" width=\"12\" height=\"520\" fill=\"#e9b95e\"/>\n", svg);
    fputs("  <text x=\"205\" y=\"345\" fill=\"#ffffff\" font-family=\"sans-serif\" font-size=\"92\" font-weight=\"700\">", svg);
    xml_text(svg, name);
    fputs("</text>\n  <text x=\"210\" y=\"425\" fill=\"#d7edf2\" font-family=\"sans-serif\" font-size=\"34\">", svg);
    xml_text(svg, id);
    fputs(" - Development Build ", svg);
    xml_text(svg, version);
    fputs("</text>\n  <text x=\"210\" y=\"610\" fill=\"#d7edf2\" font-family=\"sans-serif\" font-size=\"28\">", svg);
    xml_text(svg, build);
    fputs("</text>\n</svg>\n", svg);
    if (fclose(svg) != 0) {
        perror("GAGAL: penulisan SVG tidak selesai");
        return 1;
    }

    printf("Wallpaper SVG dibuat: %s\n", output);
    printf("Target pemasangan dari project.env: %s\n", install_path);
    printf("Langkah berikutnya: periksa SVG, ekspor PNG, lalu simpan PNG pada target tersebut saat implementasi starter.\n");
    return 0;
}
