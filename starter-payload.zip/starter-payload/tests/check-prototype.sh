#!/usr/bin/env bash
# Test statis dan test jalan untuk starter payload. Tidak menggunakan sudo.
set -euo pipefail

ROOT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
CONFIG="$ROOT_DIR/configs/project.env"
CHECK="$ROOT_DIR/bin/trpl-healthcheck.sh"

fail() { printf 'FAIL: %s\n' "$1" >&2; exit 1; }

[[ -f "$CONFIG" ]] || fail "configs/project.env belum ada"
[[ -x "$CHECK" ]] || fail "bin/trpl-healthcheck.sh belum executable; jalankan chmod +x"
[[ -f "$ROOT_DIR/branding/wallpaper/generate-brand.c" ]] || fail "branding/wallpaper/generate-brand.c belum ada"
command -v cc >/dev/null 2>&1 || fail "compiler C (cc) belum tersedia; lihat panduan pemasangan build-essential"
cc -Wall -Wextra -std=c11 -fsyntax-only "$ROOT_DIR/branding/wallpaper/generate-brand.c" || fail "source C tidak dapat dikompilasi"
bash -n "$CHECK"

read_value() {
  awk -F= -v wanted="$1" '$1 == wanted && $2 ~ /^".*"$/ { value=$0; sub(/^[^=]*="/, "", value); sub(/"$/, "", value); print value; exit }' "$CONFIG"
}
for field in OS_NAME OS_ID OS_VERSION BUILD_CHANNEL BUILD_ID BRANDING_WALLPAPER_PATH; do
  value="$(read_value "$field")"
  [[ -n "$value" ]] || fail "$field kosong atau tidak memakai format KEY=\"VALUE\""
  [[ "$value" != *TODO* && "$value" != *todo-* ]] || fail "$field masih placeholder"
done

OS_ID="$(read_value OS_ID)"
[[ "$OS_ID" =~ ^[a-z0-9][a-z0-9-]{1,31}$ ]] || fail "OS_ID hanya boleh huruf kecil, angka, dan tanda hubung"

output="$($CHECK)"
grep -q 'STATUS: PASS' <<<"$output" || fail "healthcheck tidak menyatakan PASS"

printf 'PASS: konfigurasi valid, skrip valid, dan healthcheck berjalan.\n'
