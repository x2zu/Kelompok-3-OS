# Perbandingan GNOME dan XFCE

Gunakan lembar ini sebelum menghapus paket utama GNOME. Isi berdasarkan percobaan langsung pada VM kelompok.

| Hal yang diuji | GNOME sebelum perubahan | XFCE sebelum penghapusan GNOME | Catatan kelompok |
|---|---|---|---|
| Cara membuka daftar aplikasi | | | |
| Lokasi panel dan jalan pintas | | | |
| Cara membuka pengaturan desktop | | | |
| Pengelola berkas yang tersedia | | | |
| Aplikasi yang mudah ditemukan | | | |

## Pilihan desain kelompok

- Siapa pengguna sasaran desktop ini?
- Aplikasi apa yang perlu mudah dibuka?
- Mengapa kelompok memilih tema, wallpaper, panel, dan jalan pintas tersebut?
- Apakah tampilan XFCE sudah mendukung kebutuhan pengguna? Jelaskan berdasarkan percobaan.

## Catatan setelah penghapusan paket GNOME

- Apakah XFCE dapat dibuka setelah VM dimulai ulang?
- Aplikasi dan fungsi apa saja yang diuji?
- Apakah panel, jaringan, dan layar login berfungsi?
- Bukti tangkapan layar yang disertakan:

## Boot splash Plymouth

- Snapshot sebelum perubahan Plymouth:
- Nama tema yang tersedia dan dipilih:
- Tema yang tampil setelah reboot (catat jika tidak terlihat):
- Hasil pemeriksaan `update-initramfs`:
- Bukti E09:
