# Pengumpulan Project Akhir 0

- Nama kelompok:
- Nama anggota:
- Pengguna sasaran desktop:
- Ringkasan perubahan:
- Nama berkas laporan:
- Nama SVG hasil program:
- Lokasi source C yang sudah dimodifikasi:

## Pembagian tugas

| Nama anggota | Tanggung jawab | Berkas atau bukti yang dibuat |
|---|---|---|
| | | |
| | | |
| | | |
| | | |
| | | |

## Daftar berkas

Pastikan berkas berikut tersedia sebelum pengumpulan:

- [ ] `payload/configs/project.env` (salinan lokal konfigurasi starter; buang semua placeholder sebelum menyerahkan)
- [ ] `payload/branding/wallpaper/generate-brand.c`
- [ ] Catatan perintah kompilasi ke `/tmp/generate-brand` (program sementara tidak perlu dikumpulkan)
- [ ] SVG source dan PNG hasil ekspor di `payload/branding/wallpaper/`
- [ ] `evidence/E07-banner-dan-SVG.png` (bukti dari VM kelompok)
- [ ] `payload/bin/trpl-healthcheck.sh`
- [ ] Bukti E01 sampai E08, termasuk E07 banner ASCII dan SVG dari VM kelompok
- [ ] `evidence/E09-plymouth-boot.png` atau video singkat splash Plymouth dari VM
- [ ] `PROJECT_BRIEF.md`
- [ ] `perbandingan-desktop.md`
- [ ] `laporan-kelompok.pdf`

Jangan sertakan kata sandi, token, ISO, berkas disk virtual, atau tembolok.
