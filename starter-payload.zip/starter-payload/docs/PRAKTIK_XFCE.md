# Praktik XFCE dan boot splash Plymouth

Panduan ini digunakan pada VM Ubuntu Desktop kelompok, bukan pada macOS. Hasil akhir praktik adalah XFCE tanpa paket desktop GNOME. Buat snapshot VirtualBox `baseline-project-akhir-0` dan pastikan dosen mengetahui bahwa GNOME akan dihapus serta tema boot splash akan diubah.

## 1. Pasang XFCE dan LightDM

Buka Terminal di dalam VM:

```bash
sudo apt update
sudo apt install xfce4 lightdm
```

Baca daftar paket dan kebutuhan ruang. Bila diminta memilih display manager, pilih `lightdm`. Jika ada paket yang akan dihapus atau daftar tidak dipahami, jawab `N` lalu minta dosen memeriksa.

Mulai ulang VM. Pada layar login, pilih `Xfce Session`. Uji menu `Applications`, `Settings Manager`, terminal, pengelola berkas, jaringan, lalu keluar dan masuk kembali. Simpan tangkapan layar sesi XFCE sebelum melanjutkan.

## 2. Atur tampilan desktop XFCE

- Tema dan ikon: Applications > Settings > Appearance.
- Wallpaper: Applications > Settings > Desktop > Background, atau klik kanan desktop > Desktop Settings.
- Panel dan jalan pintas aplikasi: Applications > Settings > Panel. Pertahankan menu Applications dan panel utama.

Simpan wallpaper di folder pribadi pengguna. Lengkapi `perbandingan-desktop.md` dengan pengguna sasaran, pilihan tema, panel, jalan pintas aplikasi, dan alasan desain.

## 3. Simulasikan penghapusan desktop GNOME

Lakukan setelah XFCE berfungsi. Opsi `-s` hanya simulasi; belum ada paket yang dihapus.

```bash
sudo apt -s purge ubuntu-desktop ubuntu-desktop-minimal ubuntu-session gnome-shell gnome-control-center gdm3
```

Simpan seluruh output. Periksa semua paket yang APT rencanakan untuk dihapus. Jangan lanjut jika ada komponen XFCE (`xfce4`, `xfce4-session`, `xfce4-panel`, `xfwm4`), `lightdm`, `network-manager`, kernel, atau aplikasi yang dibutuhkan. Dosen harus meninjau keseluruhan daftar dan snapshot sebelum menyetujui. Untuk memastikan tidak ada paket desktop GNOME yang tertinggal, periksa daftar paket terpasang setelah purge; pustaka bersama boleh tetap terpasang jika diperlukan aplikasi lain. Jangan hapus pustaka satu per satu secara manual.

## 4. Hapus GNOME setelah simulasi disetujui

Jalankan hanya setelah dosen menyetujui simulasi. Jika daftar aktual berbeda dari simulasi, jawab `N`.

```bash
sudo apt purge ubuntu-desktop ubuntu-desktop-minimal ubuntu-session gnome-shell gnome-control-center gdm3
```

Perintah tersebut menghapus paket GNOME yang disebutkan beserta konfigurasi paketnya. Sebagian pustaka GNOME dapat tetap terpasang bila masih dibutuhkan aplikasi lain. Jangan menjalankan `sudo apt autoremove` dan jangan memasang GNOME kembali. Jika APT menawarkan penghapusan paket lain yang tidak disetujui, jawab `N` dan minta dosen memeriksa.

Mulai ulang VM dan uji XFCE: menu, panel, Settings, terminal, pengelola berkas, jaringan, serta proses keluar dan masuk kembali. Simpan tangkapan layar hasilnya.

## 5. Ubah boot splash Plymouth

Plymouth menampilkan splash saat Linux mulai menyala. Langkah ini bukan sekadar pengaturan wallpaper; ia mengubah konfigurasi yang dimuat dari initramfs. Buat snapshot kedua setelah XFCE berfungsi dan GNOME dihapus, lalu minta dosen mendampingi. Jangan ubah GRUB, UEFI, kernel, atau parameter boot.

Pasang paket tema yang tersedia:

```bash
sudo apt update
sudo apt -s install plymouth-themes
```

Baca daftar perubahan simulasi. Jika disetujui dosen, ulangi perintah dengan mengganti `-s` menjadi pemasangan normal:

```bash
sudo apt install plymouth-themes
```

Jika ada paket penting yang akan dihapus, jawab `N`. Minta dosen melihat tema yang tersedia:

```bash
plymouth-set-default-theme --list
```

Pilih nama tema yang benar-benar tampil pada daftar. Jangan gunakan teks `NAMA_TEMA` apa adanya dan jangan menebak nama tema. Dosen kemudian mendampingi perubahan default dan pembuatan ulang initramfs:

```bash
sudo plymouth-set-default-theme NAMA_TEMA
sudo update-initramfs -u
```

Ganti `NAMA_TEMA` dengan nama yang terverifikasi di VM. Pembuatan initramfs dapat memerlukan waktu. Jangan matikan VM selama proses berjalan. Setelah selesai, mulai ulang dan amati boot splash. Tema mungkin tidak terlihat pada VM tertentu karena konfigurasi grafis/firmware; catat kondisi aktual, jangan mengklaim berhasil bila splash tidak tampak. Simpan bukti foto atau video singkat sebagai E09.

## 6. Jika terjadi masalah

Tidak ada langkah untuk kembali ke GNOME. Jika layar login, XFCE, atau proses boot gagal setelah perubahan, jangan memperbaiki paket, GRUB, atau initramfs sendiri. Pulihkan snapshot sebelum Plymouth bersama dosen melalui VirtualBox.

## Referensi paket

- Ubuntu Packages, `xfce4` untuk Ubuntu 24.04 LTS: https://packages.ubuntu.com/noble/xfce4
- Ubuntu Packages, `ubuntu-desktop-minimal`: https://packages.ubuntu.com/noble/ubuntu-desktop-minimal
- Ubuntu Packages, `lightdm`: https://packages.ubuntu.com/noble/lightdm
- Ubuntu Packages, `plymouth-themes`: https://packages.ubuntu.com/noble/plymouth-themes
- Ubuntu Packages, `plymouth-theme-spinner`: https://packages.ubuntu.com/noble/plymouth-theme-spinner
