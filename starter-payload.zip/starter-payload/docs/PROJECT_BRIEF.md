# Ringkasan Rancangan Desktop Kelompok

Isi dokumen ini bersama anggota kelompok. Gunakan kalimat sendiri dan sertakan alasan untuk setiap pilihan.

## Anggota dan pembagian tugas

| Nama | Tanggung jawab | Bukti pekerjaan |
|---|---|---|
| | Operator VM : Wildan Nur Awaludin
| | Pemeriksa keselamatan : Fachrezy Centrino Duo
| | Perancang tampilan : Reivan Elsyafir Pratama
| | Pencatat bukti : Ainul Rohmah
| | Penguji dan penyaji : Laura Asmiranda

## Pengguna dan kebutuhan

- Siapa pengguna yang dituju?
- Apa pekerjaan yang perlu dilakukan pengguna?
- Masalah apa yang ingin dibantu oleh desktop ini?
- Aplikasi apa yang harus mudah ditemukan?

## Identitas desktop

- Nama prototipe:
- Nama kelompok:
- Versi:
- Nilai identitas `OS_NAME`, `OS_ID`, `OS_VERSION`, `BUILD_CHANNEL`, dan `BUILD_ID` pada `configs/project.env`:
- Alasan memilih nama:
- Nama berkas SVG yang dibuat program:
- Perubahan yang dilakukan pada source C:
- Bagian banner ASCII dan SVG yang diubah:

## Rancangan tampilan

| Bagian | Pilihan kelompok | Alasan berdasarkan kebutuhan pengguna |
|---|---|---|
| Wallpaper | | |
| Tema jendela | | |
| Panel dan menu | | |
| Jalan pintas aplikasi | | |
| Boot splash Plymouth | | tema tersedia yang dipilih; hasil boot aktual |

## Pengujian dan keselamatan

- Aplikasi dan fungsi yang diuji sebelum penghapusan:
- Isi simulasi `apt -s purge` yang diperiksa:
- Nama dosen yang menyetujui dan waktu persetujuan:
- Aplikasi dan fungsi yang diuji setelah penghapusan:
- Masalah yang ditemukan dan langkah pemulihan:

## Sumber aset

Catat sumber, pembuat, lisensi (jika diketahui), dan perubahan pada gambar yang digunakan.
Program `branding/wallpaper/generate-brand.c` membaca `configs/project.env`; catat warna dan elemen yang diubah dari starter resmi. Program menulis SVG pada `branding/wallpaper/<OS_ID>-<OS_VERSION>.svg` dan menampilkan identitas yang sama pada banner terminal.
Nama PNG ekspor dan nilai `BRANDING_WALLPAPER_PATH`:

## Kesimpulan kelompok

Jelaskan apakah tampilan membantu pengguna yang dituju dan bukti apa yang mendukung kesimpulan tersebut.
